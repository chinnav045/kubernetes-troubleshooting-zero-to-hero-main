# Invalid Image

`ImagePullBackoff` can be caused if the pod runs with an invalid image or typo in the image name or even a non-existent image.

Watch the demo on the youtube channel for practical understanding.